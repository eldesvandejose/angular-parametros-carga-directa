import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-supplier-data',
  templateUrl: './supplier-data.component.html',
  styleUrls: ['./supplier-data.component.css']
})
export class SupplierDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
