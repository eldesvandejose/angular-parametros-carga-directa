import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-storing-incoming',
  templateUrl: './storing-incoming.component.html',
  styleUrls: ['./storing-incoming.component.css']
})
export class StoringIncomingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
